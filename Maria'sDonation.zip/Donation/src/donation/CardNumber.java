/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package donation;

/**
 *
 * @author gwyne
 */
public class CardNumber extends Name{
    private String cardnumber;
    private String expiryDate;
    private String CVC;

    public CardNumber() {
    }

    public CardNumber(String cardnumber, String expiryDate, String CVC) {
        this.cardnumber = cardnumber;
        this.expiryDate = expiryDate;
        this.CVC = CVC;
    }

    public String getCardnumber() {
        return cardnumber;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public String getCVC() {
        return CVC;
    }

    public void setCardnumber(String cardnumber) {
        this.cardnumber = cardnumber;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public void setCVC(String CVC) {
        this.CVC = CVC;
    }

    @Override
    public String toString() {
        return "CardNumber{" + "cardnumber=" + cardnumber + ", expiryDate=" + expiryDate + ", CVC=" + CVC + '}';
    }
    
}