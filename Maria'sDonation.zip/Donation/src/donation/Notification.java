/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package donation;

/**
 *
 * @author gwyne
 */
public class Notification {
    private String Notify;
    private String Donator;

    public Notification() {
    }

    public Notification(String Notify, String Donator) {
        this.Notify = Notify;
        this.Donator = Donator;
    }

    public String getNotify() {
        return Notify;
    }

    public String getDonator() {
        return Donator;
    }

    public void setNotify(String Notify) {
        this.Notify = Notify;
    }

    public void setDonator(String Donator) {
        this.Donator = Donator;
    }

    @Override
    public String toString() {
        return "Notification{" + "Notify=" + Notify + ", Donator=" + Donator + '}';
    }
    
    
}
