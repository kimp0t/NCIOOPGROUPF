/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reggui;

import java.util.Date;

/**
 *
 * @author imbol
 */
///this class displays informations that have been filled through registrationc
public class Information extends Form{
    private String Addinfo, Displayinfo;

    public Information() {
    }

    public Information(String Addinfo, String Displayinfo, String Firstname, String Lastname, String FamilyID, Date Dob, String Gender, String Address) {
        super(Firstname, Lastname, FamilyID, Dob, Gender, Address);
        this.Addinfo = Addinfo;
        this.Displayinfo = Displayinfo;
    }

    public String getAddinfo() {
        return Addinfo;
    }

    public void setAddinfo(String Addinfo) {
        this.Addinfo = Addinfo;
    }

    public String getDisplayinfo() {
        return Displayinfo;
    }

    public void setDisplayinfo(String Displayinfo) {
        this.Displayinfo = Displayinfo;
    }

    @Override
    public String toString() {
        return "Information{" + "Addinfo=" + Addinfo + ", Displayinfo=" + Displayinfo + '}';
    }
    
    
}
